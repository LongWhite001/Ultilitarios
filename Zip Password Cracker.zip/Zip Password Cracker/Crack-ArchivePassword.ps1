#requires -Version 5.0

<#
.SYNOPSIS
  Script para quebrar ou visualizar senha de arquivos .7z, .rar ou .zip usando uma wordlist.
  Baixa e instala automaticamente as dependências (7-Zip e Rar for Windows).
  Permite selecionar o arquivo via janela gráfica e exibe o resultado em pop-up.

.NOTES
  Autor: GitHub Copilot para LongWhite001
  Uso: Execute em PowerShell (recomenda-se rodar como administrador para instalar dependências).
#>

function Install-7Zip {
    $zipPath = "$env:ProgramFiles\7-Zip\7z.exe"
    if (-not (Test-Path $zipPath)) {
        Write-Host "7-Zip não encontrado. Instalando..."
        $url = "https://www.7-zip.org/a/7z2201-x64.exe"
        $installer = "$env:TEMP\7zsetup.exe"
        Invoke-WebRequest -Uri $url -OutFile $installer
        Start-Process -Wait -FilePath $installer -ArgumentList "/S"
        Remove-Item $installer
        if (-not (Test-Path $zipPath)) {
            [System.Windows.Forms.MessageBox]::Show("Erro ao instalar o 7-Zip!", "Erro", 0)
            exit 1
        }
    }
    return $zipPath
}

function Install-UnRAR {
    $rarPath = "$env:ProgramFiles\WinRAR\UnRAR.exe"
    if (-not (Test-Path $rarPath)) {
        Write-Host "UnRAR não encontrado. Instalando..."
        $url = "https://www.rarlab.com/rar/unrarw64.exe"
        $installer = "$env:TEMP\unrarsetup.exe"
        Invoke-WebRequest -Uri $url -OutFile $installer
        Start-Process -Wait -FilePath $installer -ArgumentList "/S"
        Remove-Item $installer
        if (-not (Test-Path $rarPath)) {
            [System.Windows.Forms.MessageBox]::Show("Erro ao instalar o UnRAR!", "Erro", 0)
            exit 1
        }
    }
    return $rarPath
}

Add-Type -AssemblyName System.Windows.Forms

# Pergunta ao usuário a ação desejada
$action = [System.Windows.Forms.MessageBox]::Show(
    "Deseja quebrar a senha (Sim) ou apenas visualizar (Não)?", 
    "Escolha a ação", 
    [System.Windows.Forms.MessageBoxButtons]::YesNoCancel
)
if ($action -eq [System.Windows.Forms.DialogResult]::Cancel) { exit }

$onlyShow = $action -eq [System.Windows.Forms.DialogResult]::No

# Seleciona o arquivo
$OpenFileDialog = New-Object System.Windows.Forms.OpenFileDialog
$OpenFileDialog.Filter = "Arquivos Compactados|*.zip;*.rar;*.7z"
$OpenFileDialog.Title = "Selecione o arquivo compactado"
$null = $OpenFileDialog.ShowDialog()

if (-not $OpenFileDialog.FileName) {
    [System.Windows.Forms.MessageBox]::Show("Nenhum arquivo selecionado.", "Cancelado", 0)
    exit
}

$archive = $OpenFileDialog.FileName
$ext = [System.IO.Path]::GetExtension($archive).ToLower()

# Seleciona a wordlist
$OpenFileDialog.Filter = "Wordlist|*.txt"
$OpenFileDialog.Title = "Selecione a wordlist (wordlist.txt)"
$null = $OpenFileDialog.ShowDialog()

if (-not $OpenFileDialog.FileName) {
    [System.Windows.Forms.MessageBox]::Show("Nenhuma wordlist selecionada.", "Cancelado", 0)
    exit
}
$wordlist = $OpenFileDialog.FileName

# Instala dependências conforme necessário
$sevenZipPath = Install-7Zip
if ($ext -eq ".rar") { $unrarPath = Install-UnRAR }

function Test-7zPassword {
    param($archive, $password)
    $proc = Start-Process -FilePath $sevenZipPath -ArgumentList "t", "`"$archive`"", "-p$password" -NoNewWindow -PassThru -Wait -RedirectStandardOutput "$env:TEMP\7zlog.txt"
    $output = Get-Content "$env:TEMP\7zlog.txt"
    Remove-Item "$env:TEMP\7zlog.txt" -ErrorAction SilentlyContinue
    return $output -match "Everything is Ok"
}

function Test-RarPassword {
    param($archive, $password)
    $proc = Start-Process -FilePath $unrarPath -ArgumentList "t", "`"$archive`"", "-p$password" -NoNewWindow -PassThru -Wait -RedirectStandardOutput "$env:TEMP\rarlog.txt"
    $output = Get-Content "$env:TEMP\rarlog.txt"
    Remove-Item "$env:TEMP\rarlog.txt" -ErrorAction SilentlyContinue
    return $output -match "All OK"
}

function Crack-Password {
    param($archive, $ext, $wordlist)
    foreach ($password in Get-Content $wordlist) {
        $password = $password.Trim()
        if ($password.Length -eq 0) { continue }
        if ($ext -eq ".zip" -or $ext -eq ".7z") {
            if (Test-7zPassword $archive $password) { return $password }
        } elseif ($ext -eq ".rar") {
            if (Test-RarPassword $archive $password) { return $password }
        }
    }
    return $null
}

# Tenta quebrar ou visualizar a senha
$result = $null
if ($ext -in ".7z", ".zip", ".rar") {
    $result = Crack-Password $archive $ext $wordlist
} else {
    [System.Windows.Forms.MessageBox]::Show("Tipo de arquivo não suportado.", "Erro", 0)
    exit
}

if ($result) {
    $msg = "Senha encontrada:`n$result"
    if ($onlyShow) {
        [System.Windows.Forms.MessageBox]::Show($msg, "Visualização de Senha", 0)
    } else {
        # Extrai para pasta temporária usando a senha
        $dest = "$env:TEMP\Cracked-Archive-$(Get-Random)"
        mkdir $dest | Out-Null
        if ($ext -eq ".zip" -or $ext -eq ".7z") {
            & $sevenZipPath x "`"$archive`"" -p"$result" -o"$dest" -y | Out-Null
        } elseif ($ext -eq ".rar") {
            & $unrarPath x "`"$archive`"" "$dest" -p"$result" | Out-Null
        }
        [System.Windows.Forms.MessageBox]::Show("$msg`nArquivos extraídos para: $dest", "Senha Quebrada", 0)
    }
} else {
    [System.Windows.Forms.MessageBox]::Show("Senha não encontrada na wordlist.", "Falha", 0)
}

Write-Host "Pressione qualquer tecla para fechar..."
$x = $host.UI.RawUI.ReadKey("NoEcho,IncludeKeyDown")