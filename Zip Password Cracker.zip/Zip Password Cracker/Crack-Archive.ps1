# PowerShell Script: Crack-Archive.ps1
# Quebra senha de arquivos .7z, .rar e .zip usando wordlist
# Baixa e instala dependências se necessário

# Função para instalar 7-Zip se não estiver presente
function Install-7Zip {
    $sevenZipPath = "$env:ProgramFiles\7-Zip\7z.exe"
    if (-not (Test-Path $sevenZipPath)) {
        Write-Host "Baixando e instalando 7-Zip..."
        $url = "https://www.7-zip.org/a/7z2301-x64.exe"
        $installer = "$env:TEMP\7zsetup.exe"
        Invoke-WebRequest -Uri $url -OutFile $installer
        Start-Process -FilePath $installer -ArgumentList "/S" -Wait
        Remove-Item $installer
    } else {
        Write-Host "7-Zip já está instalado."
    }
}

# Função para instalar o módulo BurntToast para notificação (popup)
function Install-BurntToast {
    if (-not (Get-Module -ListAvailable -Name BurntToast)) {
        Write-Host "Instalando módulo BurntToast para notificações..."
        Install-Module -Name BurntToast -Force -Scope CurrentUser
    }
}

# Criação da wordlist.txt se não existir
if (-not (Test-Path ".\wordlist.txt")) {
    Write-Host "Criando wordlist.txt padrão..."
    @"
123456
password
qwerty
senha
admin
letmein
12345678
12345
123456789
1234
2315
dragon
Batman
batman
godofwar
GodofWar
god of war
God of War
eusoufoda123
senha
qwerty123
qwerty1
123456789
12345678
12345
102030
admin
Brasil
Qwerty123
1234567
Qwerty1!
Qwerty123!
Qwerty12
Qwerty1234
Qwerty1?
1234567890
Qwerty123?
123123
Qwerty1
2315@
2315
password
long
bailong
Long
BaiLong
Brasil
brasil
Brazil
brazil
123456
123456789
102030
senha
1234
10203
123123
123
1234567
654321
1234567890
gabriel
abc123
q1w2e3r4t5y6
101010
159753
123321
senha123
mirantte
flamengo
felicidade
qwerty
felipe
121212
111111
142536
familia
password
sucesso
vitoria
matheus
rafael
junior
112233
gustavo
mariana
1q2w3e4r
000000
novo
131313
lucas123
estrela
daniel
musica
camila
eduardo
dragon
teste
admin
admin123
admin1235
admin1236
admin1237
admin1234567
admin12345678
admin123456789
ADMIN
Batman
batman
long
Gh3
eusoufoda123
senha
qwerty123
qwerty1
123456789
12345678
12345
102030
1234567
Qwerty1!
Qwerty123!
Qwerty12
Qwerty1234
Qwerty1?
1234567890
Qwerty123?
123123
Qwerty1
2315@
2315
password
long
bailong
Long
BaiLong
Bailong
12345
102030
senha
12345678
1234
10203
123123
123
1234567
654321
1234567890
gabriel
abc123
q1w2e3r4t5y6
101010
159753
123321
senha123
mirantte
flamengo
felicidade
qwerty
felipe
121212
111111
142536
familia
password
sucesso
vitoria
matheus
rafael
junior
112233
gustavo
mariana
1q2w3e4r
000000
novo
131313
lucas123
estrela
daniel
musica
camila
eduardo
Guilherme
1234
12345
teste
admin
admin123
admin1235
admin1236
admin1237
admin1234567
dragon
admin12345678
admin123456789
ADMIN
2315
q1w2e3r4
q1w2e3r4t5
FELIPE10
Felipe10
felipe10
Ovofrito123
Ovofrito
OvoFrito
ovofrito123
ovofrito
OVOFRITO
5632
5632G
5632g
Ferrari
ferrari
FERRARI
101979
Baton
Baton123
baton
baton123
3rMv@hFXnNkwRv4
KMnGChHW@Az99gX
guilherme
"@ | Out-File -Encoding utf8 .\wordlist.txt
}

# Instala dependências
Install-7Zip
Install-BurntToast

# Carrega o módulo BurntToast
Import-Module BurntToast

# Abre janela para seleção do arquivo
Add-Type -AssemblyName System.Windows.Forms
$OpenFileDialog = New-Object System.Windows.Forms.OpenFileDialog
$OpenFileDialog.Filter = "Arquivos compactados (*.7z;*.zip;*.rar)|*.7z;*.zip;*.rar"
$OpenFileDialog.Title = "Selecione o arquivo que deseja quebrar a senha"
$null = $OpenFileDialog.ShowDialog()
$ArchivePath = $OpenFileDialog.FileName

if (-not $ArchivePath) {
    Write-Host "Nenhum arquivo selecionado. Saindo..."
    exit
}

# Caminho do 7z.exe
$sevenZip = "$env:ProgramFiles\7-Zip\7z.exe"
if (-not (Test-Path $sevenZip)) {
    $sevenZip = "C:\Program Files\7-Zip\7z.exe"
}

# Função para testar uma senha
function Test-ArchivePassword {
    param (
        [string]$Archive,
        [string]$Password
    )
    $out = & "$sevenZip" t "-p$Password" -y "$Archive" 2>&1
    if ($out -match "Everything is Ok") {
        return $true
    }
    return $false
}

# Tenta quebrar a senha usando a wordlist
$Wordlist = Get-Content .\wordlist.txt
$PasswordFound = $false
foreach ($pass in $Wordlist) {
    Write-Host "Testando senha: $pass"
    if (Test-ArchivePassword -Archive $ArchivePath -Password $pass) {
        $PasswordFound = $true
        $FoundPassword = $pass
        break
    }
}

# Exibe o resultado em um popup
if ($PasswordFound) {
    New-BurntToastNotification -Text "Senha encontrada!", "A senha do arquivo é: $FoundPassword"
    [System.Windows.Forms.MessageBox]::Show("Senha encontrada: $FoundPassword", "Sucesso!", 'OK', 'Information')
} else {
    New-BurntToastNotification -Text "Falha!", "Nenhuma senha da wordlist abriu o arquivo."
    [System.Windows.Forms.MessageBox]::Show("Nenhuma senha da wordlist abriu o arquivo.", "Falha", 'OK', 'Error')
}

Write-Host "`nPressione qualquer tecla para fechar..."
$x = $host.UI.RawUI.ReadKey("NoEcho,IncludeKeyDown")