#requires -version 5.0
Add-Type -AssemblyName System.Windows.Forms

function Show-OpenFileDialog {
    $OpenFileDialog = New-Object System.Windows.Forms.OpenFileDialog
    $OpenFileDialog.Title = "Selecione o arquivo protegido por senha"
    $OpenFileDialog.Filter = "Arquivos suportados (*.zip;*.rar;*.7z;*.tar;*.wim)|*.zip;*.rar;*.7z;*.tar;*.wim"
    $OpenFileDialog.Multiselect = $false
    if ($OpenFileDialog.ShowDialog() -eq "OK") {
        return $OpenFileDialog.FileName
    }
    else {
        return $null
    }
}

function Get-Wordlist {
    # Palavra-passe comuns e exemplo (adicione mais conforme necessário)
    @(
        "123456",
        "password",
        "senha",
        "admin",
        "qwerty",
        "letmein",
        "12345678",
        "iloveyou",
        "123123",
        "test123",
        "1234"
    )
}

function Test-ZipPassword {
    param($FilePath, $Password)
    try {
        # Requer 7-Zip instalado e no PATH
        $process = Start-Process -FilePath "7z" -ArgumentList "t `"$FilePath`" -p$Password" -NoNewWindow -PassThru -Wait -RedirectStandardOutput -RedirectStandardError
        $output = $process.StandardOutput.ReadToEnd() + $process.StandardError.ReadToEnd()
        return ($output -match "Everything is Ok")
    } catch {
        return $false
    }
}

function Test-RarPassword {
    param($FilePath, $Password)
    try {
        $process = Start-Process -FilePath "7z" -ArgumentList "t `"$FilePath`" -p$Password" -NoNewWindow -PassThru -Wait -RedirectStandardOutput -RedirectStandardError
        $output = $process.StandardOutput.ReadToEnd() + $process.StandardError.ReadToEnd()
        return ($output -match "Everything is Ok")
    } catch {
        return $false
    }
}

function Test-7zPassword {
    param($FilePath, $Password)
    try {
        $process = Start-Process -FilePath "7z" -ArgumentList "t `"$FilePath`" -p$Password" -NoNewWindow -PassThru -Wait -RedirectStandardOutput -RedirectStandardError
        $output = $process.StandardOutput.ReadToEnd() + $process.StandardError.ReadToEnd()
        return ($output -match "Everything is Ok")
    } catch {
        return $false
    }
}

function Test-TarPassword {
    param($FilePath, $Password)
    # TAR normalmente não suporta senha, exceto se combinado com outro formato
    return $false
}

function Test-WimPassword {
    param($FilePath, $Password)
    # WIM não suporta senha nativamente, mas se estiver criptografado talvez seja possível
    return $false
}

function Test-ArchivePassword {
    param($FilePath, $Password)
    $ext = [System.IO.Path]::GetExtension($FilePath).ToLower()
    switch ($ext) {
        ".zip" { return Test-ZipPassword $FilePath $Password }
        ".rar" { return Test-RarPassword $FilePath $Password }
        ".7z"  { return Test-7zPassword  $FilePath $Password }
        ".tar" { return Test-TarPassword $FilePath $Password }
        ".wim" { return Test-WimPassword $FilePath $Password }
        default { return $false }
    }
}

# Programa principal
Write-Host "--------------------------------------------"
Write-Host "        Quebrador de senha de arquivos      "
Write-Host "--------------------------------------------"

$file = Show-OpenFileDialog
if (-not $file) {
    Write-Host "Nenhum arquivo selecionado. Encerrando."
    exit
}

if (-not (Get-Command "7z" -ErrorAction SilentlyContinue)) {
    Write-Host "O 7-Zip CLI ('7z') não está instalado ou não está no PATH. Instale o 7-Zip e tente novamente."
    exit
}

$wordlist = Get-Wordlist
Write-Host "Testando $(($wordlist | Measure-Object).Count) senhas para o arquivo: $file"
$senhaAchada = $null

foreach ($senha in $wordlist) {
    Write-Host "Testando senha: $senha"
    if (Test-ArchivePassword -FilePath $file -Password $senha) {
        $senhaAchada = $senha
        break
    }
}

if ($senhaAchada) {
    Write-Host "`n====================="
    Write-Host "Senha encontrada: " -NoNewline
    Write-Host "$senhaAchada" -ForegroundColor Yellow -BackgroundColor DarkBlue
    Write-Host "====================="

    Write-Host "`nPressione qualquer tecla para sair..."
    [void][System.Console]::ReadKey($true)
} else {
    Write-Host "Nenhuma senha encontrada na wordlist."
    Write-Host "`nPressione qualquer tecla para sair..."
    [void][System.Console]::ReadKey($true)
}