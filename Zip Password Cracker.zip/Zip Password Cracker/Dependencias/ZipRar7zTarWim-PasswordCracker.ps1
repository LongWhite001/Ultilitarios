# Script PowerShell para quebrar senhas de arquivos .zip, .rar, .7z, .tar, .wim usando wordlist própria.
# Requisitos: 7-Zip instalado (7z.exe no PATH) e wordlist.txt na mesma pasta do script.
Add-Type -AssemblyName System.Windows.Forms

function Select-FileDialog {
    $dialog = New-Object System.Windows.Forms.OpenFileDialog
    $dialog.Filter = "Arquivos compactados (*.zip;*.rar;*.7z;*.tar;*.wim)|*.zip;*.rar;*.7z;*.tar;*.wim|Todos arquivos (*.*)|*.*"
    $dialog.Title = "Selecione o arquivo compactado para quebrar a senha"
    if ($dialog.ShowDialog() -eq [System.Windows.Forms.DialogResult]::OK) {
        return $dialog.FileName
    }
    return $null
}

function Test-Password7z {
    param(
        [string]$Archive,
        [string]$Password
    )
    $cmd = "7z.exe t -p`"$Password`" -y -- `"$Archive`""
    $output = & cmd.exe /c $cmd 2>&1
    if ($output -match "Everything is Ok") { return $true }
    if ($output -match "Wrong password") { return $false }
    if ($output -match "Can not open encrypted archive") { return $false }
    if ($output -match "Errors: 1") { return $false }
    return $false
}

# Caminho do script e wordlist
$scriptDir = Split-Path -Parent $MyInvocation.MyCommand.Definition
$wordlistPath = Join-Path $scriptDir "wordlist.txt"

if (!(Test-Path $wordlistPath)) {
    Write-Host "Arquivo wordlist.txt não encontrado no diretório do script. Crie um arquivo wordlist.txt com possíveis senhas." -ForegroundColor Yellow
    pause
    exit
}

# Selecionar arquivo
$arquivo = Select-FileDialog
if (-not $arquivo) {
    Write-Host "Nenhum arquivo selecionado. Saindo."
    exit
}

Write-Host "Arquivo selecionado: $arquivo"
$senhas = Get-Content $wordlistPath

Write-Host "Iniciando ataque de força bruta com $(($senhas).Count) senhas..."
$senhaEncontrada = $null

foreach ($senha in $senhas) {
    Write-Host "Testando senha: $senha"
    if (Test-Password7z -Archive $arquivo -Password $senha) {
        $senhaEncontrada = $senha
        break
    }
}

if ($senhaEncontrada) {
    Write-Host ""
    Write-Host "SENHA ENCONTRADA: $senhaEncontrada" -ForegroundColor Green
} else {
    Write-Host ""
    Write-Host "Senha não encontrada na wordlist." -ForegroundColor Red
}

Write-Host ""
Write-Host "Pressione qualquer tecla para sair..."
[void][System.Console]::ReadKey($true)